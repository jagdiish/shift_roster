<?php
ob_start();
?>
<?php
include('db_connection.php');
?>

<?php
if(isset($_GET['did']) && $_GET['did']!=''){
$del=mysql_query("DELETE FROM login WHERE id=".$_GET['did']);

}
header('Location:show_users.php?result=ok_del');

?>
<?php
ob_end_flush();
?>