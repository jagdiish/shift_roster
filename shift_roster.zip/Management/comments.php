
<?php
include('db_connection.php');
?>
<?php
include('header-include.php');
?>
<?php
//$name=$_POST['name'];
//$comment=$_POST['comment'];
//$submit=$_POST['submit'];
 

 
if(isset($_POST['submit']))
{
if($_POST['name']&& $_POST['comment'])
{
$insert=mysql_query("INSERT INTO comment_table (name,comment) VALUES ('".$_POST['name']."','".$_POST['comment']."') ");
//echo "<meta HTTP-EQUIV='REFRESH' content='0; url=comments.php'>";
}
else
{
echo "please fill out all fields";
}
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Comment box</title>
</head>

<body>
<center>
<form action="comments.php" method="POST">
  <table>
    <tr>
      <td>Name: <br>
        <input type="text" name="name"/></td>
    </tr>
    <tr>
      <td colspan="2">Comment: </td>
    </tr>
    <tr>
      <td colspan="5"><textarea name="comment" class="form-control"></textarea></td>
    </tr>
    <tr>
      <td colspan="2"><input type="submit" name="submit" value="Comment"></td>
    </tr>
  </table>
</form>
<?php
/*$dbLink = mysql_connect("localhost","root","");
    mysql_query("SET character_set_results=utf8", $dbLink);
    mb_language('uni');
    mb_internal_encoding('UTF-8');
*/	
 
$getquery=mysql_query("SELECT * FROM comment_table ORDER BY id DESC");
while($rows=mysql_fetch_assoc($getquery))
{
$id=$rows['id'];
$name=$rows['name'];
$comment=$rows['comment'];
echo "User:" .$name . '<br/>' . '<br/>'. "Comments:". $comment . '<br/>' . '<br/>' . '<hr size="1"/>'
;}
?>
<div class="col-md-6"> 
  <!-- general form elements disabled -->
  <div class="box box-warning">
    <div class="box-header">
      <h3 class="box-title">General Elements</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <form role="form">
        <!-- text input -->
        <div class="form-group">
          <label>Text</label>
          <input type="text" class="form-control" placeholder="Enter ..."/>
        </div>
        
        <!-- textarea -->
        <div class="form-group">
          <label>Textarea</label>
          <textarea class="form-control" rows="3" placeholder="Enter ..."></textarea>
        </div>
      </form>
    </div>
    <!-- /.box-body --> 
  </div>
  <!-- /.box --> 
</div>
<?php
include('footer-include.php');
?>
