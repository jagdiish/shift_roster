<?php
include('db_connection.php');
?>
<?php
session_start();
?>
<?php
if(!isset($_SESSION['identify'])){
header('Location:login.php');	
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>AdminLTE | Dashboard</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<!-- Ionicons -->
<link href="//code.ionicframework.com/ionicons/1.5.2/css/ionicons.min.css" rel="stylesheet" type="text/css" />
<!-- Morris chart -->
<link href="css/morris/morris.css" rel="stylesheet" type="text/css" />
<!-- jvectormap -->
<link href="css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
<!-- Date Picker -->
<link href="css/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
<!-- Daterange picker -->
<link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
<!-- bootstrap wysihtml5 - text editor -->
<link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
<!-- Theme style -->
<link href="css/AdminLTE.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/stylesheet.css" />
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
var rowCount = 1;
function addMoreRows(frm) {
rowCount ++;
var recRow = '<p id="rowCount'+rowCount+'"><tr><td><input name="achieve[]" type="text" size="4%"  maxlength="120" /></td><td><input name="achieve[]" class="" type="text" size="180%"  maxlength="" style="margin: 0px;"/></td></tr> <a href="javascript:void(0);" onclick="removeRow('+rowCount+');"><img src="img/Delete.ico" alt="Delete Row" /></a></p>';
jQuery('#addedRows').append(recRow);
}

function removeRow(removeNum) {
jQuery('#rowCount'+removeNum).remove();
}
</script>
</head>
<body class="skin-blue">
<!-- header logo: style can be found in header.less -->
<header <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='index.php'? 'class="active"' : '');?> class="header"> <a href="index.php" class="logo"> 
  <!-- Add the class icon to your logo image or logo icon to add the margining --> 
  AdminLTE </a> 
  <!-- Header Navbar: style can be found in header.less -->
  <nav class="navbar navbar-static-top" role="navigation"> 
    <!-- Sidebar toggle button--> 
    <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </a>
    <div class="navbar-right">
      <ul class="nav navbar-nav">
        <!-- Messages: style can be found in dropdown.less--> 
        
        <!-- Notifications: style can be found in dropdown.less --> 
        
        <!-- Tasks: style can be found in dropdown.less --> 
        
        <!-- User Account: style can be found in dropdown.less -->
        <li class="dropdown user user-menu"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <span>
          <?php			  
			  $sel=mysql_query(" SELECT * FROM login WHERE id=".$_SESSION['identify']);		  
			  $row=mysql_fetch_array($sel);
				echo $row['username'];
			  ?>
          <i class="caret"></i></span> </a>
          <ul class="dropdown-menu">
            <!-- User image -->
            <li class="user-header bg-light-blue"> <img src="img/avatar04.png" class="img-circle" alt="User Image" />
              <p>
                <?php			  
			  $sel=mysql_query(" SELECT * FROM login WHERE id=".$_SESSION['identify']);		  
			  $row=mysql_fetch_array($sel);
				echo $row['username'];	  
			  
			  ?>
                - Web Developer<small>Member since Nov. 2012</small> </p>
            </li>
            <!-- Menu Body -->
            <li class="user-body">
              <div class="col-xs-4 text-center"> <a href="#">Followers</a> </div>
              <div class="col-xs-4 text-center"> <a href="#">Sales</a> </div>
              <div class="col-xs-4 text-center"> <a href="#">Friends</a> </div>
            </li>
            <!-- Menu Footer-->
            <li class="user-footer">
              <div class="pull-left"> <a href="#" class="btn btn-default btn-flat">Profile</a> </div>
              <div class="pull-right"> <a href="logout.php" class="btn btn-default btn-flat">Sign out</a> </div>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </nav>
</header>
<div class="wrapper row-offcanvas row-offcanvas-left">
<!-- Left side column. contains the logo and sidebar -->
<aside class="left-side sidebar-offcanvas"> 
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar"> 
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image"> <img src="img/avatar04.png" class="img-circle" alt="User Image" /> </div>
      <div class="pull-left info">
        <p>Hello,
          <?php			  
			  $sel=mysql_query(" SELECT * FROM login WHERE id=".$_SESSION['identify']);		  
			  $row=mysql_fetch_array($sel);
				echo $row['username'];		  
			  
			  ?>
        </p>
        <a href="#"><i class="fa fa-circle text-success"></i> Online</a> </div>
    </div>
    <!-- search form --> 
    <!--<form action="#" method="get" class="sidebar-form">
      <div class="input-group">
        <input type="text" name="q" class="form-control" placeholder="Search..."/>
        <span class="input-group-btn">
        <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
        </span> </div>
    </form>--> 
    <!-- /.search form --> 
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu">
      <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='index.php'? 'class="active' : '');?>> <a href="index.php"> <i class="fa fa-dashboard"></i> <span>Dashboard</span> </a> </li>
      <li> <a href="mailbox.php"> <i class="fa fa-envelope"></i> <span>Mailbox</span> <small class="badge pull-right bg-yellow"></small> </a> </li>
      <li class="treeview"> <a href="#"> <i class="fa fa-folder"></i> <span>Users</span> <i class="fa fa-angle-left pull-right"></i> </a>
        <ul class="treeview-menu">
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='add_user.php'? 'class="active"' : '');?>><a href="add_user.php"><i class="fa fa-angle-double-right"></i> Add New User</a></li>
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='show_users.php'? 'class="active"' : '');?>><a href="show_users.php"><i class="fa fa-angle-double-right"></i> View User</a></li>
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='show_users.php'? 'class="active"' : '');?>><a href="pages/examples/register.html"><i class="fa fa-angle-double-right"></i> Register</a></li>
          <!--<li><a href="pages/examples/lockscreen.html"><i class="fa fa-angle-double-right"></i> Feedback</a></li>
          <li><a href="pages/examples/404.html"><i class="fa fa-angle-double-right"></i> View feedback</a></li>
          <li><a href="pages/examples/500.html"><i class="fa fa-angle-double-right"></i> add</a></li>
          <li><a href="pages/examples/blank.html"><i class="fa fa-angle-double-right"></i> add</a></li>-->
        </ul>
      </li>
      <li class="treeview"> <a href="#"> <i class="fa fa-folder"></i> <span>Feedabck</span> <i class="fa fa-angle-left pull-right"></i> </a>
        <ul class="treeview-menu">
          <li<?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='display_fb.php'? 'class="active"' : '');?>><a href="display_fb.php"><i class="fa fa-angle-double-right"></i>View Feedback</a></li>
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='feedback.php'? 'class="active"' : '');?>><a href="feedback.php"><i class="fa fa-angle-double-right"></i> Add Feedback</a></li>
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='fb_draft.php'? 'class="active"' : '');?>><a href="fb_draft.php"><i class="fa fa-angle-double-right"></i> Feedback in Draft</a></li>
          <!--<li><a href="pages/examples/lockscreen.html"><i class="fa fa-angle-double-right"></i> Feedback</a></li>
          <li><a href="pages/examples/404.html"><i class="fa fa-angle-double-right"></i> View feedback</a></li>
          <li><a href="pages/examples/500.html"><i class="fa fa-angle-double-right"></i> add</a></li>
          <li><a href="pages/examples/blank.html"><i class="fa fa-angle-double-right"></i> add</a></li>-->
        </ul>
      </li>
    </ul>
  </section>
  <!-- /.sidebar --> 
</aside>

<!-- Right side column. Contains the navbar and content of the page -->
<aside class="right-side">
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1> Feedback <small>Control panel</small> </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Dashboard</li>
  </ol>
</section>
<section class="content">
<div class="row"> 
  <!-- left column -->
  <div class="col-md-12"> 
    <!-- general form elements -->
    <div class="box box-primary">
      <div class="box-header"> </div>
      <!-- /.box-header --> 
      <!-- form start -->
      <?php
	  $selcount=mysql_num_rows(mysql_query("SELECT * FROM feedback_table WHERE usr_id=".$_SESSION['identify']));
	  if($selcount == 0)
	  {
	  ?>
      <form name="myform" role="form" action="fb_insert_query.php" method="post" enctype="multipart/form-data" >
        <div class="box-body">
          <div class="form-group">
            <label for="exampleInputEmail1">Career Objective</label>
            <input type="text" class="form-control" id="exampleInputEmail1" name="career" placeholder="Enter" >
          </div>
        </div>
        <!-- /.box-body -->
        <label for="">Achievements:</label>
        <table width="100%" height="" border="" rules="" style="background:#fff;margin-bottom: 20px">
          <tr height="">
            <td style="font-size:14px; text-align:center">Sno</td>
            <td style="font-size:14px;text-align:center">Achievement</td>
            <td ><span style="font:normal 12px agency, arial; color:blue; text-decoration:underline; cursor:pointer;" onclick="addMoreRows(this.form);"><img src="img/Add.ico" alt="Add Row" /> </span></td>
          </tr>
          <tr id="rowId">
            <td></td>
            <td class="center-td"><input name="achieve[]" class="form-control" type="text" id="achieve"  value="" style="width:100%" size="100%"/></td>
        </table>
        <div id="addedRows"></div>
        </td>
        </tr>
        <label for="">Short Term Goals:</label>
        <table border="1" style="margin-bottom: 20px;width:100%;">
          <tr>
            <th style="text-align: center;">3 Months</th>
            <td ><input size="150%" id="short1" type="text" name="short1" value="" /></td>
          </tr>
          <tr>
            <th style="width: 200px;text-align: center;">Check Point Date</th>
            <td ><input size="150%" id="short2" type="text" name="short2" value="" /></td>
          </tr>
          <tr>
            <th style="width: 200px;text-align: center;">6 Months</th>
            <td ><input size="150%" id="short3" type="text" name="short3" value="" /></td>
          </tr>
          <tr>
            <th style="width: 200px;text-align: center;">Check Point Date</th>
            <td ><input size="150%" id="short4" type="text" name="short4" value="" /></td>
          </tr>
        </table>
        <label for="">Long Term Goals:</label>
        <table border="1" style="margin-bottom: 20px;width:100%;">
          <tr>
            <th style="text-align: center;">End of 2009</th>
            <td ><input size="150%" id="long1" type="text" name="long1" value="" /></td>
          </tr>
          <tr>
            <th style="text-align: center;">Check Point Date</th>
            <td ><input size="150%" id="long2" type="text" name="long2" value="" /></td>
          </tr>
          <tr>
            <th style="text-align: center;">End of 2010</th>
            <td ><input size="150%" id="long3" type="text" name="long3" value="" /></td>
          </tr>
          <tr>
            <th style="text-align: center;">Check Point Date</th>
            <td ><input size="150%" id="long4" type="text" name="long4" value="" /></td>
          </tr>
        </table>
        <label for="">Evaluation Matrix:</label>
        <table border="1" style="margin-bottom: 20px; width:100%;">
          <tr>
            <th style="width: 280px;text-align: center;">HTML Development</th>
            <td ><label id="html" style="margin-left:10px" for="">5</label>
              <input size="50%" checked="checked" type="radio" name="eval1" value="5" id="html1" />
              <label style="margin-left:10px" for="">4</label>
              <input size="50%" type="radio" name="eval1" value="4" id="html2" />
              <label style="margin-left:10px" for="">3</label>
              <input size="50%" type="radio" name="eval1" value="3" id="html3" />
              <label style="margin-left:10px" for="">2</label>
              <input size="50%" type="radio" name="eval1" value="2" id="html4" />
              <label style="margin-left:10px" for="">1</label>
              <input size="50%" type="radio" name="eval1" value="1" id="html5" /></td>
          </tr>
          <tr>
            <th style="width: 200px;text-align: center;">PHP Programming</th>
            <td ><label style="margin-left:10px" for="">5</label>
              <input checked="checked" size="50%" type="radio" name="eval2" value="5" />
              <label style="margin-left:10px" for="">4</label>
              <input size="50%" type="radio" name="eval2" value="4" />
              <label style="margin-left:10px" for="">3</label>
              <input size="50%" type="radio" name="eval2" value="3" />
              <label style="margin-left:10px" for="">2</label>
              <input size="50%" type="radio" name="eval2" value="2" />
              <label style="margin-left:10px" for="">1</label>
              <input size="50%" type="radio" name="eval2" value="1" /></td>
              </td>
          </tr>
          <tr>
            <th style="width: 200px;text-align: center;">Template Design</th>
            <td ><label style="margin-left:10px" for="">5</label>
              <input checked="checked" size="50%" type="radio" name="eval3" value="5" />
              <label style="margin-left:10px" for="">4</label>
              <input size="50%" type="radio" name="eval3" value="4" />
              <label style="margin-left:10px" for="">3</label>
              <input size="50%" type="radio" name="eval3" value="3" />
              <label style="margin-left:10px" for="">2</label>
              <input size="50%" type="radio" name="eval3" value="2" />
              <label style="margin-left:10px" for="">1</label>
              <input size="50%" type="radio" name="eval3" value="1" /></td>
              </td>
          </tr>
          <tr>
            <th style="width: 200px;text-align: center;">Communication skills</th>
            <td ><label style="margin-left:10px" for="">5</label>
              <input checked="checked" size="50%" type="radio" name="eval4" value="5" required="required"/>
              <label style="margin-left:10px" for="">4</label>
              <input size="50%" type="radio" name="eval4" value="4" />
              <label style="margin-left:10px" for="">3</label>
              <input size="50%" type="radio" name="eval4" value="3" />
              <label style="margin-left:10px" for="">2</label>
              <input size="50%" type="radio" name="eval4" value="2" />
              <label style="margin-left:10px" for="">1</label>
              <input size="50%" type="radio" name="eval4" value="1" /></td>
              </td>
          </tr>
          <tr>
            <th style="width: 200px;text-align: center;">Flexibility </th>
            <td ><label style="margin-left:10px" for="">5</label>
              <input checked="checked" size="50%" type="radio" name="eval5" value="5" required="required" />
              <label style="margin-left:10px" for="">4</label>
              <input size="50%" type="radio" name="eval5" value="4" />
              <label style="margin-left:10px" for="">3</label>
              <input size="50%" type="radio" name="eval5" value="3" />
              <label style="margin-left:10px" for="">2</label>
              <input size="50%" type="radio" name="eval5" value="2" />
              <label style="margin-left:10px" for="">1</label>
              <input size="50%" type="radio" name="eval5" value="1" /></td>
              </td>
          </tr>
          <tr>
            <th style="width: 200px;text-align: center;">Wordpress</th>
            <td ><label style="margin-left:10px" for="">5</label>
              <input checked="checked" size="50%" type="radio" name="eval6" value="5" required="required" />
              <label style="margin-left:10px" for="">4</label>
              <input size="50%" type="radio" name="eval6" value="4" />
              <label style="margin-left:10px" for="">3</label>
              <input size="50%" type="radio" name="eval6" value="3" />
              <label style="margin-left:10px" for="">2</label>
              <input size="50%" type="radio" name="eval6" value="2" />
              <label style="margin-left:10px" for="">1</label>
              <input size="50%" type="radio" name="eval6" value="1" /></td>
              </td>
          </tr>
          <tr>
            <th style="width: 200px;text-align: center;">jQuery</th>
            <td ><label style="margin-left:10px" for="">5</label>
              <input checked="checked" size="50%" type="radio" name="eval7" value="5" required="required"/>
              <label style="margin-left:10px" for="">4</label>
              <input size="50%" type="radio" name="eval7" value="4" />
              <label style="margin-left:10px" for="">3</label>
              <input size="50%" type="radio" name="eval7" value="3" />
              <label style="margin-left:10px" for="">4</label>
              <input size="50%" type="radio" name="eval7" value="2" />
              <label style="margin-left:10px" for="">1</label>
              <input size="50%" type="radio" name="eval7" value="1" /></td>
              </td>
          </tr>
        </table>
        <div class="box-footer">
          <button onClick="return(validation());" style="margin-right:30px" type="submit" name="submit" class="btn btn-primary">SEND</button>
          <button type="submit" name="save" class="btn btn-primary">SAVE AS DRAFT</button>
        </div>
      </form>
      <?php } else { ?>
      <div class="box-body">
        <div class="form-group">
          <label for="exampleInputEmail1">You have already submitted the feedback.</label>
        </div>
      </div>
      <?php } ?>
    </div>
  </div>
</div>

<!-- VALIDATION SCRIPT -->

<script>

function validation(){

var career = document.myform.exampleInputEmail1.value;


$('.form-control').removeClass("border-red");
if(career==''){
$('#exampleInputEmail1').addClass("border-red");
document.getElementById('exampleInputEmail1').focus();
return false;
}

var achieve = document.myform.achieve.value;
$('.form-control').removeClass("border-red");
if(achieve==''){
$('#achieve').addClass("border-red");
document.getElementById('achieve').focus();
return false;
}

var short1 = document.myform.short1.value;
$('.form-control').removeClass("border-red");
if(short1==''){
$('#short1').addClass("border-red");
document.getElementById('short1').focus();
return false;
}

var short2 = document.myform.short2.value;
$('.form-control').removeClass("border-red");
if(short2==''){
$('#short2').addClass("border-red");
document.getElementById('short2').focus();
return false;
}

var short3 = document.myform.short3.value;
$('.form-control').removeClass("border-red");
if(short3==''){
$('#short3').addClass("border-red");
document.getElementById('short3').focus();
return false;
}

var short4 = document.myform.short4.value;
$('.form-control').removeClass("border-red");
if(short4==''){
$('#short4').addClass("border-red");
document.getElementById('short4').focus();
return false;
}


var long1 = document.myform.long1.value;
$('.form-control').removeClass("border-red");
if(long1==''){
$('#long1').addClass("border-red");
document.getElementById('long1').focus();
return false;
}

var long2 = document.myform.long2.value;
$('.form-control').removeClass("border-red");
if(long2==''){
$('#long2').addClass("border-red");
document.getElementById('long2').focus();
return false;
}

var long3 = document.myform.long3.value;
$('.form-control').removeClass("border-red");
if(long3==''){
$('#long3').addClass("border-red");
document.getElementById('long3').focus();
return false;
}

var long4 = document.myform.long4.value;
$('.form-control').removeClass("border-red");
if(long4==''){
$('#long4').addClass("border-red");
document.getElementById('long4').focus();
return false;
}
else { return true;}


}

</script>

<?php
include('footer-include.php');
?>