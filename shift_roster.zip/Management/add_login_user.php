<?php
include('db_connection.php');
?>
<?php
include('header-include.php');
?>
<form class="" name="" method="post" enctype="multipart/form-data">
  USERNAME:
  <input type="text" name="uname" value="" /><br/>
  PASSWORD:
  <input type="password" name="pwd" value="" /><br/>
  EMAIL:
  <input type="email" name="email" value="" /><br/>
  MOBILE:
  <input type="text" name="mob" value="" /><br/>
  ROLE:
  <select name="role">
    <option value=""></option>
    <option value="Management">MANAGEMENT</option>
    <option value="Lead">LEAD</option>
     <option value="User">USER</option>
  </select><br/>
  AGE:
  <input type="text" name="age" value="" /><br/>
  SEX:
  <select name="sex">
    <option value=""></option>
    <option value="Male">MALE</option>
    <option value="Female">FEMALE</option>
  </select><br/>
  USERLEVEL:
  <select name="level">
    <option value=""></option>
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
  </select><br/>
  <input type="submit" name="submit" value="ADD" />
</form>



<?php
$msg='';
if(isset($_POST['submit']))
{
$ins=mysql_query("INSERT INTO login(username,pwd,email,mobile,role,age,sex,userlevel) VALUES
('".$_POST['uname']."',
'".$_POST['pwd']."',
'".$_POST['email']."',
'".$_POST['mob']."',
'".$_POST['role']."',
'".$_POST['age']."',
'".$_POST['sex']."',
'".$_POST['level']."')");

$msg='User Added !!!';
}
if($msg!=''){ ?>
<div style="color:red"> 

<?php echo $msg; ?> </div>

<?php } ?>




<?php
include('footer-include.php');
?>