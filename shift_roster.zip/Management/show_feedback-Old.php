<?php
include('db_connection.php');
?>
<?php
include('header-include.php');
?>
<?php //list of feedbacks and comments page ?>
<h1>FEEDBACKS</h1>
<?php /*?><?php
$sel=mysql_query("SELECT *,login.username as user FROM feedback_table INNER JOIN login on login.id=feedback_table.send_id");
while($row=mysql_fetch_array($sel)){

echo $row['username'];
}?><?php */?>
<?php

$sel=mysql_query("SELECT * FROM feedback_table WHERE usr_id=".$_SESSION['identify']);
while($row=mysql_fetch_array($sel)){ ?>
<table border="1" style="width:100%;">
  <tr style="">
    <th style="padding:10px; color:#605e5c">Career:</th>
    <td style="padding:10px; color:#999"><?php echo $row['career']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px; color:#605e5c">Achievements</th>
    <td style="padding:10px;color:#999"><?php echo $row['achieve']; ?></td>
  </tr>
  <tr>
    <th rowspan="4" style="padding:10px;color:#605e5c">Short Term Goals:</th>
    <th rowspan="" style="padding:10px; color:#605e5c">3 Months</th>
    <td style="padding:10px;color:#999"><?php echo $row['3_month']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Check Point Date</th>
    <td style="padding:10px;color:#999"><?php echo $row['3_check']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">6 Months</th>
    <td style="padding:10px;color:#999"><?php echo $row['6_month']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Check Point Date</th>
    <td style="padding:10px;color:#999"><?php echo $row['6_check']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c" rowspan="4">Long Term Goals:</th>
    <th style="padding:10px;color:#605e5c" rowspan="">End of 2009</th>
    <td style="padding:10px;color:#999"><?php echo $row['long_end1']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Check Point Date</th>
    <td style="padding:10px;color:#999"><?php echo $row['checkpt1']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">End of 2010</th>
    <td style="padding:10px;color:#999"><?php echo $row['long_end2']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Check Point Date</th>
    <td style="padding:10px;color:#999"><?php echo $row['checkpt2']; ?></td>
  </tr>
  <tr>
    <th rowspan="7" style="padding:10px;color:#605e5c">Evaluation Matrix:</th>
    <th rowspan="" style="padding:10px;color:#605e5c">HTML Development</th>
    <td style="padding:10px;color:#999"><?php echo $row['html']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">PHP Programming</th>
    <td style="padding:10px;color:#999"><?php echo $row['php']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Template Design</th>
    <td style="padding:10px;color:#999"><?php echo $row['long_end2']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Communication skills</th>
    <td style="padding:10px;color:#999"><?php echo $row['design']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Flexibility </th>
    <td style="padding:10px;color:#999"><?php echo $row['flex']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Wordpress</th>
    <td style="padding:10px;color:#999"><?php echo $row['word']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">jQuery</th>
    <td style="padding:10px;color:#999"><?php echo $row['jquery']; ?></td>
  </tr>
</table>
<?php } ?>
<?php
if(isset($_POST['submit'])){
$ins=mysql_query("INSERT INTO fb_comment_table(sender_id,comment) VALUES('".$_SESSION['identify']."','".$_POST['comment']."')");

}
?>
<h4>COMMENTS:</h4>

<!-- --COMMENT BOX-- -->
<?php
$sel=mysql_query("SELECT *,login.username as cmtname, fb_comment_table.id as tabid FROM fb_comment_table INNER JOIN login on login.id=fb_comment_table.sender_id WHERE fb_comment_table.sender_id = ".$_SESSION['identify']);
while($row=mysql_fetch_array($sel)){
?>
<div style="background-color: #eee;border: 1px solid #eee; margin: 20px 0; width: 500px; height: 100px; position:relative;">
  <dt style="background-color: #fff;border-bottom: 0 solid #c7371d;font-weight: bold; padding: 5px 10px 5px 15px;"> 
  
  <a href="" style="color: #1111aa;"><?php echo $row['username']."<br>";?></a>	 
  
  <a style="position:absolute;top:0;right:10px;" href="del_cmt.php?dcid=<?php echo $row['tabid']; ?>">
  <img src="img/Delete.ico" width="15px" height="15px" /></a> 
  
  <a name="edit" style="position:absolute;top:0px;right:40px;" href="edit_cmt.php?ccid=<?php echo $row['tabid']; ?>">
  <img src="img/pencil.ico" width="15px" height="15px" /></a>
</dt>  
  <dd style="margin: 0;padding: 10px 15px;">
    <p style="font-size: 95%;line-height: 1.3em;margin: 0; padding: 0;"><?php echo $row['comment']."<br>";?></p>
  </dd>

</div>
<?php } ?> 



<form role="form" name="" method="post" enctype="multipart/form-data">
  <div class="comment" style="margin-top: 80px;">
    <div class="form-group">
      <label>Comment:</label>
      <textarea name="comment" class="form-control" rows="3" placeholder="Enter ..."></textarea>
    </div>
  </div>
  <div class="box-footer">
    <button type="submit" name="submit" class="btn btn-primary">POST</button>
  </div>
</form>
<?php
include('footer-include.php');
?>
<?php /*?><?php

$select=mysql_query("SELECT * FROM fb_comment_table");
while($row=mysql_fetch_array($select)){
?>
  <a style="position:absolute;top:0;right:10px;" href="del_cmt.php?dcid=<?php echo $row['id']; ?>">
  <img src="img/Delete.ico" width="15px" height="15px" /></a> 
  
  <a name="edit" style="position:absolute;top:0px;right:40px;" href="edit_cmt.php?ccid=<?php echo $row['id']; ?>">
  <img src="img/pencil.ico" width="15px" height="15px" /></a>
  

  <?php } ?> <?php */?>