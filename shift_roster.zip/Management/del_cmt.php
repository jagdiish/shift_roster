<?php
include('db_connection.php');
?>

<?php
if(isset($_GET['dcid']) && $_GET['dcid']!=''){
$del=mysql_query("DELETE FROM fb_comment_table WHERE id=".$_GET['dcid']);
}
header('Location:show_feedback.php');
?>