<?php
include('db_connection.php');
?>
<?php
include('header-include.php');
?>
<div style="margin-bottom:40px;" class="buts">
  <div class="box-footer" id="prof" > <a href="edit_profile.php?pid=<?php echo $row['id'] ?>">
    <button type="button" name="edit" class="btn btn-primary" style=" float:left; margin-right:10px;"> Edit Profile </button>
    </a> </div>
  <div class="box-footer" id="prof1">
   <a href="delete_profile.php"> <button type="button" name="delete" class="btn btn-primary">Delete Profile</button></a>
  </div>
</div>
<?php 
$sel=mysql_query("SELECT * FROM login WHERE id=".$_SESSION['identify']);
?>
<?php while ($row=mysql_fetch_array($sel)){ ?>
<label style="width:100px;margin-bottom: 20px; float:left;";>USERNAME:</label>
<?php echo "<div style='color:#709b1d'>".$row['username']."</div>"."<br>"; ?>
<label style="width:100px;margin-bottom: 20px; float:left;">EMAIL:</label>
<?php echo "<div style='color:#709b1d'>". $row['email']."</div>"."<br>";?>
<label style="width:100px;margin-bottom: 20px; float:left;">MOBILE:</label>
<?php echo "<div style='color:#709b1d'>". $row['mobile']."</div>"."<br>";?>
<label style="width:100px;margin-bottom: 20px; float:left;">ROLE:</label>
<?php echo "<div style='color:#709b1d'>". $row['role']."</div>"."<br>";?>
<label style="width:100px;margin-bottom: 20px; float:left;">AGE:</label>
<?php echo "<div style='color:#709b1d'>". $row['age']."</div>"."<br>";?>
<label style="width:100px;margin-bottom: 20px; float:left;">SEX:</label>
<?php echo "<div style='color:#709b1d'>". $row['sex']."</div>"."<br>";?>
<?php } ?>
<?php
include('footer-include.php');
?>