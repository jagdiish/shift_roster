<?php
session_start();
include('db_connection.php');
?>

<?php
if(isset($_POST['submit'])){

$ach=implode(",", $_POST['achieve']);
$ins=mysql_query("INSERT INTO feedback_table(usr_id,career,achieve,3_month,3_check,6_month,6_check,long_end1,checkpt1,long_end2,checkpt2,html,php,design,communi,flex,word,jquery)
VALUES(
'".$_SESSION['identify']."',
'".$_POST['career']."',
'".$ach."',
'".$_POST['short1']."',
'".$_POST['short2']."',
'".$_POST['short3']."',
'".$_POST['short4']."',
'".$_POST['long1']."', 
'".$_POST['long2']."',
'".$_POST['long3']."',
'".$_POST['long4']."',
'".$_POST['eval1']."',
'".$_POST['eval2']."',
'".$_POST['eval3']."',
'".$_POST['eval4']."',
'".$_POST['eval5']."',
'".$_POST['eval6']."',
'".$_POST['eval7']."')");
}

header('Location:display_fb.php')



?>

<?php /*?>QUERY FOR SAVING IN DRAFT<?php */?>


<?php
if(isset($_POST['save'])){
$ach=implode(",", $_POST['achieve']);
$ins=mysql_query("INSERT INTO draft(career,achieve,3_month,3_check,6_month,6_check,long_end1,checkpt1,long_end2,checkpt2,html,php,design,communi,flex,word,jquery)
VALUES(
'".$_POST['career']."',
'".$ach."',
'".$_POST['short1']."',
'".$_POST['short2']."',
'".$_POST['short3']."',
'".$_POST['short4']."',
'".$_POST['long1']."', 
'".$_POST['long2']."',
'".$_POST['long3']."',
'".$_POST['long4']."',
'".$_POST['eval1']."',
'".$_POST['eval2']."',
'".$_POST['eval3']."',
'".$_POST['eval4']."',
'".$_POST['eval5']."',
'".$_POST['eval6']."',
'".$_POST['eval7']."')");
}
header('Location:display_fb.php')

?>
