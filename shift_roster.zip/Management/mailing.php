<?php
include('db_connection.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<form action="mail_query.php" name="myform" class="" method="post" enctype="multipart/form-data">
  
  <label>Email</label>
  <input type="email" name="emailto" class="form-control" placeholder="Enter ..."/><br/>
  
  <label>Subject</label>
  <input type="text" name="subject" class="form-control" placeholder="Enter ..."/><br/>
  
   <label>Message</label>
  <textarea name="message" placeholder="Enter ..."></textarea><br/>
  
  <input type="submit" name="submit" value="SUBMIT" class=""  /> 
  
</form>

</body>
</html>


