<?php
include('db_connection.php');
include('header-include.php');

if(isset($_GET['sid'])){
	$uid = $_GET['sid'];
	
	}else{
		$uid = $_SESSION['identify'];
		
		}
	
		
?>

<?php
$selfb=mysql_query("SELECT * FROM feedback_table WHERE usr_id=".$uid);
$count = mysql_num_rows($selfb);
if($count == 0){ ?>
<div class="row"> 
  <!-- left column -->
  <div class="col-md-12"> 
    <!-- general form elements -->
    <div class="box box-primary">
      <div class="box-header"> </div>
      <!-- /.box-header --> 
      <!-- form start -->
            <div class="box-body">
          <div class="form-group">
  <?php echo' <label style="color:#eb3b3b; font:  normal 20px Source Sans Pro,sans-serif;" for="exampleInputEmail1">Feedback has not been submitted by the User !</label>'; ?>
          </div>
        </div>
          </div>
  </div>
</div>

<?php
//echo '<div style="color:red; font-size:20px; text-align:left;">Feedback has not been Submitted by the User !</div>';
}


else{
//$sel=mysql_query("SELECT * FROM feedback_table WHERE usr_id=".$_SESSION['identify']);
while($row = mysql_fetch_array($selfb)){ ?>

<table class="table table-striped display" border="3" style="width:100%;">
  <tr style="">
    <th style="padding:10px; color:#605e5c">Career:</th>
    <td style="padding:10px; color:#999"><?php echo $row['career']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px; color:#605e5c">Achievements</th>
    <td style="padding:10px;color:#999"><?php echo $row['achieve']; ?></td>
  </tr>
  <tr>
    <th rowspan="4" style="padding:10px;color:#605e5c">Short Term Goals:</th>
    <th rowspan="" style="padding:10px; color:#605e5c">3 Months</th>
    <td style="padding:10px;color:#999"><?php echo $row['3_month']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Check Point Date</th>
    <td style="padding:10px;color:#999"><?php echo $row['3_check']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">6 Months</th>
    <td style="padding:10px;color:#999"><?php echo $row['6_month']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Check Point Date</th>
    <td style="padding:10px;color:#999"><?php echo $row['6_check']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c" rowspan="4">Long Term Goals:</th>
    <th style="padding:10px;color:#605e5c" rowspan="">End of 2009</th>
    <td style="padding:10px;color:#999"><?php echo $row['long_end1']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Check Point Date</th>
    <td style="padding:10px;color:#999"><?php echo $row['checkpt1']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">End of 2010</th>
    <td style="padding:10px;color:#999"><?php echo $row['long_end2']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Check Point Date</th>
    <td style="padding:10px;color:#999"><?php echo $row['checkpt2']; ?></td>
  </tr>
  <tr>
    <th rowspan="7" style="padding:10px;color:#605e5c">Evaluation Matrix:</th>
    <th rowspan="" style="padding:10px;color:#605e5c">HTML Development</th>
    <td style="padding:10px;color:#999"><?php echo $row['html']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">PHP Programming</th>
    <td style="padding:10px;color:#999"><?php echo $row['php']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Template Design</th>
    <td style="padding:10px;color:#999"><?php echo $row['long_end2']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Communication skills</th>
    <td style="padding:10px;color:#999"><?php echo $row['design']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Flexibility </th>
    <td style="padding:10px;color:#999"><?php echo $row['flex']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">Wordpress</th>
    <td style="padding:10px;color:#999"><?php echo $row['word']; ?></td>
  </tr>
  <tr>
    <th style="padding:10px;color:#605e5c">jQuery</th>
    <td style="padding:10px;color:#999"><?php echo $row['jquery']; ?></td>
  </tr>
</table>

<?php 
 $form_id = $row['id'];
}
}


?>

<?php
if($form_id=''){
	
echo '<div style="color:red; display: none;"> No !!!</div>';	
}
?>

<?php


$selfb=mysql_query("SELECT * FROM feedback_table WHERE usr_id=".$uid);

while($row = mysql_fetch_array($selfb)){ 
$form_id = $row['id'];

if(isset($_POST['submit'])){

$ins = mysql_query("INSERT INTO fb_comment_table(sender_id,from_id,comment)
					
					VALUES('".$_SESSION['identify']."','".$form_id."','".$_POST['comment']."')");

}


}
?>
<?php
$selfb=mysql_query("SELECT * FROM feedback_table WHERE usr_id=".$uid);
$count = mysql_num_rows($selfb);
if($count == 0){
echo '<div style="display:none;"></div>';
}
else{
?>
<h4>COMMENTS:</h4>

<!-- --COMMENT BOX-- -->
<?php /*?><?php
$sel=mysql_query("SELECT *,login.username as cmtname, fb_comment_table.id as tabid FROM fb_comment_table INNER JOIN login on login.id=fb_comment_table.sender_id WHERE fb_comment_table.sender_id = ".$_SESSION['identify']);
while($row=mysql_fetch_array($sel)){
?><?php */?>

<?php

$sel=mysql_query("SELECT *,login.username as cmtname,fb_comment_table.sender_id as comenter_id,fb_comment_table.from_id, fb_comment_table.id as tabid FROM fb_comment_table INNER JOIN login on login.id=fb_comment_table.sender_id  WHERE fb_comment_table.from_id = '".$form_id."'");
//$sel=mysql_query("SELECT * FROM fb_comment_table WHERE from_id=".$form_id);

while($row=mysql_fetch_array($sel)){
	 $comenter_id =  $row['comenter_id'];
?>
<div style="background-color: #eee;border: 1px solid #367fa9; margin: 20px 0; width: 100%; height: 100px; position:relative;">
  <dt style="background-color: #fff;border-bottom: 2px solid #3c8dbc;font-weight: bold; padding: 5px 10px 5px 15px;"> 
  
  <a href="" style="color: #1111aa;"><?php echo $row['username']."<br>";?></a>	 
  <?php if($_SESSION['identify'] == $comenter_id) {?>
  <a style="position:absolute;top:0;right:10px;" href="del_cmt.php?dcid=<?php echo $row['tabid']; ?>">
  <img title="Delete" src="img/Delete.ico" width="15px" height="15px" /></a> 
  
  <a name="edit" style="position:absolute;top:0px;right:40px;" href="edit_cmt.php?ccid=<?php echo $row['tabid']; ?>">
  <img title="Edit" src="img/pencil.ico" width="15px" height="15px" /></a>
</dt>  
<?php }?>
  <dd style="margin: 0;padding: 10px 15px;">
    <p style="font-size: 95%;line-height: 1.3em;margin: 0; padding: 0;"><?php echo $row['comment']."<br>";?></p>
  </dd>

</div>
<?php } ?> 


<form role="form" name="" method="post" enctype="multipart/form-data">
  <div class="comment" style="margin-top: 80px;">
    <div class="form-group">
      <label>Comment:</label>
      <textarea name="comment" class="form-control" rows="3" placeholder="Enter ..."></textarea>
    </div>
  </div>
  <div class="box-footer">
    <button type="submit" name="submit" class="btn btn-primary">POST</button>
  </div>
</form>
<?php
}
?>


<?php include('footer-include.php'); ?>