<?php
include('db_connection.php');
?>

<?php

$msg='';
$sel=mysql_query("SELECT * FROM add_user");
?>