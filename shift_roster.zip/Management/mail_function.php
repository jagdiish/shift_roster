<?php

$to = "";
$from = "";

//$Cc = "";

//$Bcc = "";
$subject = '';
$message = '';

$headers = "From: $from\n";
//$headers .="Cc: $Cc\n";
//$headers .= "Bcc: $Bcc\n";
$headers .= "MIME-Version:1.0\n";
$headers .= "Content-type: text/html \n";


mail($to, $subject, $message, $headers);

?>
