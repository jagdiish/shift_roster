<?php
include('db_connection.php');
include('header-include.php');
?>
<?php

//$sel=mysql_query("SELECT * FROM login WHERE role='User' ");

if(isset($_SESSION['userlevel']) && $_SESSION['userlevel'] == 2 ){
	
	$sel=mysql_query("SELECT * FROM login WHERE role='User' AND allocate=".$_SESSION['identify']) ;
		
}
else  if(isset($_SESSION['userlevel']) && $_SESSION['userlevel'] == 1 ){ 
$sel=mysql_query("SELECT * FROM login WHERE role='User' ORDER BY allocate ASC") ; } ?>
<?php
if(isset($_GET['result']) && $_GET['result'] == 'ok' ) {echo '<div style="color:red">User Added Successfully !!!</div>'; }
if(isset($_GET['result']) && $_GET['result'] == 'ok_del' ) {echo '<div style="color:red">User Deleted Successfully !!!</div>'; }

?>

<h2>Total Users</h2>
<table class="table table-striped" border="5" bordercolor="#999">
  <tr>
    <th>Lead</th>
    <th class="emp">EMPLOYEE ID</th>
    <th class="name">USER NAME</th>
    <th class="email">EMAIL ID</th>
    <th class="email">MOBILE</th>
    <th class="role">ROLE</th>
    <th class="role">AGE</th>
    <th class="role">SEX</th>
    <th class="action">Action</th>
  </tr>
  <?php while($row = mysql_fetch_array($sel)){ 
  
  $sel_lead=mysql_query("SELECT username FROM login WHERE id=".$row['allocate']);
			
		while($row1=mysql_fetch_array($sel_lead))
		{ 	
  ?>
  <tr>
    <td><?php echo $row1['username']; ?></td>
    <?php } ?>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['username']; ?></td>
    <td><?php echo $row['email']; ?></td>
    <td><?php echo $row['mobile']; ?></td>
    <td><?php echo $row['role']; ?></td>
    <td><?php echo $row['age']; ?></td>
    <td><?php echo $row['sex']; ?></td>
    <td><a href="edit_user.php?eid=<?php echo $row['id'] ?>"><img title="Edit" style="margin-right:20px" src="img/pencil.ico" height="15" width="15" alt="edit" /></a> <a href="del_user.php?did=<?php echo $row['id'] ?>"><img title="Delete" src="img/Delete.ico" width="15" height="15" /></a></td>
  </tr>
  <?php } ?>
</table>
<?php include('footer-include.php'); ?>
