<?php
ob_start();
?>

<?php
include('db_connection.php');
?>
<?php
include('header-include.php');
?>

<?php

$selec=mysql_query("SELECT * FROM fb_comment_table WHERE id=".$_GET['ccid']);

while($row=mysql_fetch_array($selec)){
?>

<form role="form" name="" method="post" enctype="multipart/form-data">
  <div class="comment" style="margin-top: 80px;">
    <div class="form-group">
      <label>Comment:</label>
      <textarea name="comment" class="form-control" rows="3" placeholder=""><?php echo $row['comment']; ?></textarea>
    </div>
  </div>
  <div class="box-footer">
    <button type="submit" name="submit" class="btn btn-primary">POST</button>
  </div>
</form>

<?php } ?>

<?php
if(isset($_POST['submit'])){
	
$upd=mysql_query("UPDATE fb_comment_table SET comment='".$_POST['comment']."' WHERE id=".$_GET['ccid']);	
header('Location:show_feedback.php');	
}



?>


<?php
include('footer-include.php');
?>
<?php
ob_end_flush();
?>