<?php
include('db_connection.php');
?>
<?php
include('header-include.php');
?>
<div class="col-md-12"> 
  <!-- general form elements disabled -->
  <div class="box box-warning">
    <div class="box-header">
      <h3 class="box-title">Add a New User</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
     <!-- <form role="form" action="" method="post" enctype="multipart/form-data">
       text input -->
      
      <?php

$sel=mysql_query("SELECT * FROM login WHERE id=".$_GET['eid']);

while($row=mysql_fetch_array($sel)){ ?>
      <?php /*?><form role="form" class="" name="myform" method="post" enctype="multipart/form-data" onsubmit="return(validation());">
        <div class="form-group">
          <label>Name</label>
          <input style="line-height:25px;width:200px" class="form-control" type="text" name="uname" value="<?php echo $row['username']; ?>" />
        </div>
        <div class="form-group">
          <label>Email</label>
          <input style="line-height:25px; width:200px" type="email" name="email" value="<?php echo $row['email']; ?>"/>
        </div>
        <div class="form-group">
          <label style="width:100px">MOBILE:</label>
          <input style="line-height:25px; width:200px" type="text" name="mob" value="<?php echo $row['mobile']; ?>" />
        </div>
        <div class="form-group">
          <label style="width:100px">ROLE:</label>
          <select style="width:200px" name="role">
            <option value=""></option>
            <option value="Management" <?php if ($row['role']=='Management'){ echo 'selected' ;} ?>>MANAGEMENT</option>
            <option value="Lead" <?php if ($row['role']=='Lead'){ echo 'selected' ;} ?>>LEAD</option>
            <option value="User" <?php if ($row['role']=='User'){ echo 'selected' ;} ?>>USER</option>
          </select>
        </div>
        <div class="form-group">
          <label style="width:100px">AGE:</label>
          <input style="line-height:25px; width:200px" type="text" name="age" value="<?php echo $row['age']; ?>" />
        </div>
        <div class="form-group">
          <label style="width:100px">SEX:</label>
          <select style="width:200px" name="sex">
            <option value=""></option>
            <option value="Male" <?php if ($row['sex']=='Male'){ echo 'selected' ;} ?> >MALE</option>
            <option value="Female" <?php if ($row['sex']=='Female'){ echo 'selected' ;} ?>>FEMALE</option>
          </select>
        </div>
        <div class="form-group">
          <label style="width:100px">USERLEVEL:</label>
          <select style="width:200px" name="level">
            <option value=""></option>
            <option value="1" <?php if ($row['userlevel']==1){ echo 'selected' ;} ?>>1</option>
            <option value="2" <?php if ($row['userlevel']==2){ echo 'selected' ;} ?>>2</option>
            <option value="3" <?php if ($row['userlevel']==3){ echo 'selected' ;} ?>>3</option>
          </select>
          <br/>
        </div>
        <!--<div class="form-group">
                <label>Password</label>
                <input type="password" name="pwd" class="form-control" placeholder="<?php echo $row['selection']; ?>"/>
              </div>-->
        
        <div class="box-footer">
          <button type="submit" name="submit" class="btn btn-primary" >Submit</button>
        </div>
      </form><?php */?>
      
      <!--            new                 -->
      
      <form class="editform" role="form" name="myform" method="post" enctype="multipart/form-data" onsubmit="return(validation());">
        <div class="form-group">
 <label style="width:100px;">USERNAME:</label>
 <input id="name" style="line-height:25px; width:100%"  type="text" name="uname" value="<?php echo $row['username']; ?>" />
        </div>
        <div class="form-group">
<label style="width:100px">EMAIL:</label>
 <input style="line-height:25px; width:100%" type="email" id="emails" name="email" value="<?php echo $row['email']; ?>" />
        </div>
        <div class="form-group">
 <label style="width:100px">MOBILE:</label>
<input style="line-height:25px; width:100%" type="text" id="mobile" name="mob" value="<?php echo $row['mobile']; ?>" />
        </div>
        <div class="form-group">
<label style="width:100px">ROLE:</label>
          <select style="width:100%; height:30px" id="role" name="role">
            <option value="">SELECT</option>
            <option value="Management" <?php if ($row['role']=='Management'){ echo 'selected' ;} ?>>MANAGEMENT</option>
            <option value="Lead" <?php if ($row['role']=='Lead'){ echo 'selected' ;} ?>>LEAD</option>
            <option value="User" <?php if ($row['role']=='User'){ echo 'selected' ;} ?>>USER</option>
          </select>
        </div>
        <div class="form-group">
          <label style="width:100px">AGE:</label>
          <input style="line-height:25px; width:100%" type="text" id="age" name="age" value="<?php echo $row['age']; ?>" />
        </div>
        <div class="form-group">
          <label style="width:100px">SEX:</label>
          <select style="width:100%; height:30px" id="sex" name="sex">
            <option value="">SELECT</option>
            <option value="Male" <?php if ($row['sex']=='Male'){ echo 'selected' ;} ?>>MALE</option>
            <option value="Female" <?php if ($row['sex']=='Female'){ echo 'selected' ;} ?>>FEMALE</option>
          </select>
        </div>
        <div class="form-group">
          <label style="width:100px">USERLEVEL:</label>
          <select style="width:100%; height:30px" id="level" name="level">
            <option value="">SELECT</option>
            <option value="1" <?php if ($row['userlevel']==1){ echo 'selected' ;} ?>>SUPER ADMIN</option>
            <option value="2" <?php if ($row['userlevel']==2){ echo 'selected' ;} ?>>ADMIN</option>
            <option value="3" <?php if ($row['userlevel']==3){ echo 'selected' ;} ?>>USER</option>
          </select>
        </div>
        <div class="form-group">
          <label style="width:100px">ALLOCATE TO:</label>
          <select style="width:100%; height:30px" id="allocate" name="allocate">
            <option value="">SELECT</option>
            <option value="23" <?php if ($row['allocate']==23){ echo 'selected' ;} ?>>LEAD 1</option>
            <option value="25" <?php if ($row['allocate']==25){ echo 'selected' ;} ?>>LEAD 2</option>
          </select>
        </div>
        <div class="form-group">
          <input class="btn btn-primary" type="submit" name="submit" value="ADD" />
        </div>
      </form>
      <?php } ?>
      <?php
if(isset($_POST['submit'])){
	
$upd=mysql_query("UPDATE login SET 
username='".$_POST['uname']."',
email='".$_POST['email']."',
mobile='".$_POST['mob']."',
role='".$_POST['role']."',
age='".$_POST['age']."',
sex='".$_POST['sex']."',

userlevel='".$_POST['level']."' 

WHERE id=".$_GET['eid']);	

echo"<script>window.location='index.php'</script>";
	
}

?>
    </div>
    <!-- /.box-body --> 
  </div>
  <!-- /.box --> 
</div>

<script>
function validation(){

var name= document.myform.name.value;

if(name==''){
document.getElementById('name').style.border='2px solid red';

document.getElementById('name').focus();	
return false;	
}
else {
	document.getElementById('name').style.border='';
	}



var emails= document.myform.emails.value;
if(emails==''){
document.getElementById('emails').style.border='2px solid red';
document.getElementById('emails').focus();	
return false;	
}
else {
	document.getElementById('emails').style.border='';
	}


var mobile= document.myform.mobile.value;
if(mobile=='' || isNaN(mobile) || mobile.length < 10 || mobile.length > 12 ){
document.getElementById('mobile').style.border='2px solid red';
document.getElementById('mobile').focus();	
return false;	
}
else {
	document.getElementById('mobile').style.border='';
	}


var role= document.myform.role.value;
if(role==''){
document.getElementById('role').style.border='2px solid red';

document.getElementById('role').focus();	
return false;	
}
else {
	document.getElementById('role').style.border='';
	}
	

var age= document.myform.age.value;

if(age==''){
document.getElementById('age').style.border='2px solid red';
document.getElementById('age').focus();	
return false;	
}
else {
	document.getElementById('age').style.border='';
	}
	

var sex= document.myform.sex.value;
if(sex==''){
document.getElementById('sex').style.border='2px solid red';

document.getElementById('sex').focus();	
return false;	
}
else {
	document.getElementById('sex').style.border='';

	}
	

var level= document.myform.level.value;
if(level==''){
document.getElementById('level').style.border='2px solid red';

document.getElementById('level').focus();	
return false;	
}
else {
	document.getElementById('level').style.border='';
	}
	


var allocate= document.myform.allocate.value;
if(allocate==''){
document.getElementById('allocate').style.border='2px solid red';

document.getElementById('allocate').focus();	
return false;	
}


else {
	document.getElementById('allocate').style.border='';
	return true;}
	
}

</script>
<?php
include('footer-include.php');
?>