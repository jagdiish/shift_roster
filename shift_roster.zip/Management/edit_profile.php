<?php
include('db_connection.php');
?>
<?php
include('header-include.php');
?>
<div class="col-md-6"> 
  <!-- general form elements disabled -->
  <div class="box box-warning">
    <div class="box-header">
      <h3 class="box-title">Add Profile</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <form role="form" action="" method="post" enctype="multipart/form-data">
        <!-- text input -->
        <?php
$sel=mysql_query("SELECT * FROM login WHERE id=".$_GET['pid']);
while($row=mysql_fetch_array($sel)){ ?>
        <div class="form-group">
          <label>USER NAME</label>
          <input type="text" name="username" class="form-control" value="<?php echo $row['username']; ?>"/>
        </div>
       
        <div class="form-group">
          <label>Email</label>
          <input type="email" name="email" class="form-control" value="<?php echo $row['email']; ?>"/>
        </div>
        <div class="form-group">
          <label>Mobie</label>
          <input type="text" name="mobile" class="form-control" value="<?php echo $row['mobile']; ?>"/>
        </div>
        <div class="form-group">
          <label>Role</label>
          <select class="form-control" name="role">
            <option value="Lead" <?php if($row['role']=='Lead'){ echo 'selected';}?>>Lead</option>
            <option value="Management" <?php if($row['role']=='Management'){ echo 'selected';}?>>Management</option>
          </select>
        </div>
        <div class="form-group">
          <label>Age</label>
          <input type="text" name="age" class="form-control" value="<?php echo $row['age']; ?>"/>
        </div>
        <div class="form-group">
          <label>Sex</label>
          <select class="form-control" name="sex">
            <option value="Male" <?php if($row['sex']=='Male'){ echo 'selected';}?>>Male</option>
            <option value="Female" <?php if($row['sex']=='Female'){ echo 'selected';}?>>Female</option>
          </select>
        </div>
        <div class="box-footer">
          <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        </div>
      </form>
<?php } ?>
<?php
if(isset($_POST['submit'])){
	
$upd=mysql_query("UPDATE login SET username='".$_POST['username']."',email='".$_POST['email']."',mobile='".$_POST['mobile']."',role='".$_POST['role']."',age='".$_POST['age']."',sex='".$_POST['sex']."' WHERE id=".$_GET['pid']);
	//header('Location:profile.php');
	// HERE header is not working due to old version of php.. instead of that we used <script> here
	echo '<script>window.location="profile.php" </script>';
}


?>
    </div>
    <!-- /.box-body --> 
  </div>
  <!-- /.box --> 
</div>
<?php
include('footer-include.php');
?>