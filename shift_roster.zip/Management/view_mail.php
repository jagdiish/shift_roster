<?php
include('db_connection.php');
?>

<?php

$sel="SELECT * FROM mail";
$quer=mysql_query($sel);
while($row=mysql_fetch_array($quer)){
echo $row['emp_id'];
echo "<br>";
echo $row['name'];
echo "<br>";
echo $row['email'];


}
?>