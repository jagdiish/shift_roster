<?php /*?><?php
include('db_connection.php');
?>
<?php header('Location:show_users.php?result=ok'); ?>
<?php
$msg='';
if(isset($_POST['submit']))
{
$ins=mysql_query("INSERT INTO add_user(emp_id,name,email,pwd,selection) VALUES
('".$_POST['emp_id']."',
'".$_POST['name']."',
'".$_POST['email']."',
'".$_POST['pwd']."',
'".$_POST['select']."')");

$msg='User Added !!!';
}
if($msg!=''){ ?>
<div style="color:red"> 

<?php echo $msg; ?> </div>

<?php } ?><?php */?>



<?php
include('db_connection.php');
?>
<?php header('Location:show_users.php?result=ok'); ?>
<?php
$msg='';
if(isset($_POST['submit']))
{
$ins=mysql_query("INSERT INTO add_user(emp_id,name,email,pwd,selection) VALUES
('".$_POST['emp_id']."',
'".$_POST['name']."',
'".$_POST['email']."',
'".$_POST['pwd']."',
'".$_POST['select']."')");

$msg='User Added !!!';
}
if($msg!=''){ ?>
<div style="color:red"> 

<?php echo $msg; ?> </div>

<?php } ?>