<?php
ob_start();
?>
<?php
include('db_connection.php');
?>
<?php
include('header-include.php');
?>
<form role="form" class="" name="myform" method="post" enctype="multipart/form-data" onsubmit="return(validation());">
  <div class="form-group">
    <label style="width:100px;">USERNAME:</label>
    <input id="name" style="line-height:25px; width:100%" class="form-control"  type="text" name="uname" placeholder="Fill your username" />
  </div>
  <div class="form-group">
    <label style="width:100px">PASSWORD:</label>
    <input style="line-height:25px; width:100%" type="password" class="form-control" id="pwd" name="pwd" placeholder="Your password should be atleast 4 characters" />
  </div>
  <div class="form-group">
    <label style="width:100px">EMAIL:</label>
    <input style="line-height:25px; width:100%" type="email" class="form-control" id="emails" name="email" placeholder="Fill your e-mail id" />
  </div>
  <div class="form-group">
    <label style="width:100px">MOBILE:</label>
    <input style="line-height:25px; width:100%" type="text" class="form-control" id="mobile" name="mob" placeholder="Fill your mobile number" />
  </div>
  <div class="form-group">
    <label style="width:100px">ROLE:</label>
    <select style="width:100%; height:30px" class="form-control" id="role" name="role">
      <option value="">SELECT</option>
      <option value="Management">MANAGEMENT</option>
      <option value="Lead">LEAD</option>
      <option value="User">USER</option>
    </select>
  </div>
  <div class="form-group">
    <label style="width:100px">AGE:</label>
    <input style="line-height:25px; width:100%" type="text" id="age" class="form-control" name="age" placeholder="Fill your age" />
  </div>
  <div class="form-group">
    <label style="width:100px">SEX:</label>
    <select style="width:100%; height:30px" id="sex" class="form-control" name="sex">
      <option value="">SELECT</option>
      <option value="Male">MALE</option>
      <option value="Female">FEMALE</option>
    </select>
  </div>
  <div class="form-group">
    <label style="width:100px">USERLEVEL:</label>
    <select style="width:100%; height:30px" id="level" class="form-control" name="level">
      <option value="">SELECT</option>
      <option value="1">SUPER ADMIN</option>
      <option value="2">ADMIN</option>
      <option value="3">USER</option>
    </select>
  </div>
  <div class="form-group">
    <label style="width:100px">ALLOCATE TO:</label>
    <select style="width:100%; height:30px" id="allocate" class="form-control" name="allocate">
      <option value="">SELECT</option>
      <option value="23">LEAD 1</option>
      <option value="25">LEAD 2</option>
    </select>
  </div>
  <div class="form-group">
    <input class="btn btn-primary" type="submit" name="submit" value="ADD" />
  </div>
</form>
<?php /*?><?php
$msg='';
if(isset($_POST['submit'])){

$ins=mysql_query("INSERT INTO login(username,pwd,email,mobile,role,age,sex,userlevel) VALUES
('".$_POST['uname']."',
'".$_POST['pwd']."',
'".$_POST['email']."',
'".$_POST['mob']."',
'".$_POST['role']."',
'".$_POST['age']."',
'".$_POST['sex']."',
'".$_POST['level']."')");

$msg='User Added !!!';
}
if($msg!=''){ ?>
<div style="color:red"> <?php echo $msg; ?> </div>
<?php } ?>
<?php */?>
<?php
if(isset($_POST['submit'])){
$sel=mysql_query("SELECT * FROM login WHERE username='".$_POST['uname']."' AND email='".$_POST['email']."' ");	
$num=mysql_num_rows($sel);
if($num==0){
	$row=mysql_fetch_array($sel);
	$_SESSION['identify']=$row['id'];	

$ins=mysql_query("INSERT INTO login(username,pwd,email,mobile,role,age,sex,userlevel,allocate) VALUES
('".$_POST['uname']."',
'".$_POST['pwd']."',
'".$_POST['email']."',
'".$_POST['mob']."',
'".$_POST['role']."',
'".$_POST['age']."',
'".$_POST['sex']."',
'".$_POST['level']."',
'".$_POST['allocate']."')");	
	
	}
else {
	
echo "User Already Exists";

	}
}

?>
<?php  
$sel=mysql_query("SELECT * FROM login WHERE allocate='Lead1' ");
while($row=mysql_fetch_array($sel)){
	echo $row['username']."<br>";
	echo $row['allocate'];
}
?>
<script>
function validation(){

var name= document.myform.name.value;

if(name==''){
document.getElementById('name').style.border='2px solid red';
document.getElementById('name').style.padding='10px';
document.getElementById('name').focus();	
return false;	
}
else {
	document.getElementById('name').style.border='';
	document.getElementById('name').style.padding='';
	}


var pwd= document.myform.pwd.value;
if(pwd=='' || pwd.length<4){
document.getElementById('pwd').style.border='2px solid red';
document.getElementById('pwd').style.padding='10px';
document.getElementById('pwd').focus();	
return false;	
}
else {
	document.getElementById('pwd').style.border='';
	document.getElementById('pwd').style.padding='';
	}


var emails= document.myform.emails.value;
if(emails==''){
document.getElementById('emails').style.border='2px solid red';
document.getElementById('emails').style.padding='10px';
document.getElementById('emails').focus();	
return false;	
}
else {
	document.getElementById('emails').style.border='';
	document.getElementById('emails').style.padding='';
	}


var mobile= document.myform.mobile.value;
if(mobile=='' || isNaN(mobile) || mobile.length < 10 || mobile.length > 12 ){
document.getElementById('mobile').style.border='2px solid red';
document.getElementById('mobile').style.padding='10px';
document.getElementById('mobile').focus();	
return false;	
}
else {
	document.getElementById('mobile').style.border='';
	document.getElementById('mobile').style.padding='';
	}


var role= document.myform.role.value;
if(role==''){
document.getElementById('role').style.border='2px solid red';

document.getElementById('role').focus();	
return false;	
}
else {
	document.getElementById('role').style.border='';
	}
	

var age= document.myform.age.value;
var age = /^[0-9]+$/;  
if(age==''){
document.getElementById('age').style.border='2px solid red';
document.getElementById('age').style.padding='10px';
document.getElementById('age').focus();	
return false;	
}
else {
	document.getElementById('age').style.border='';
	document.getElementById('age').style.padding='';
	}
	

var sex= document.myform.sex.value;
if(sex==''){
document.getElementById('sex').style.border='2px solid red';

document.getElementById('sex').focus();	
return false;	
}
else {
	document.getElementById('sex').style.border='';

	}
	

var level= document.myform.level.value;
if(level==''){
document.getElementById('level').style.border='2px solid red';

document.getElementById('level').focus();	
return false;	
}
else {
	document.getElementById('level').style.border='';
	}
	


var allocate= document.myform.allocate.value;
if(allocate==''){
document.getElementById('allocate').style.border='2px solid red';

document.getElementById('allocate').focus();	
return false;	
}


else {
	document.getElementById('allocate').style.border='';
	return true;}
	
}
</script>
<?php
include('footer-include.php');
?>
<?php
ob_end_flush();
?>