<?php
include('db_connection.php');
?>
<?php
include('header-include.php');
?>



<div class="col-md-6"> 
        <!-- general form elements disabled -->
        <div class="box box-warning">
          <div class="box-header">
            <h3 class="box-title">Add Profile</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <form role="form" action="add_profile_query.php" method="post" enctype="multipart/form-data">
              <!-- text input -->
              <div class="form-group">
                <label>USER NAME</label>
                <input type="text" name="username" class="form-control" placeholder="Enter ..."/>
              </div>
              <div class="form-group">
                <label>Password</label>
                <input type="password" name="pwd" class="form-control" placeholder="Enter ..."/>
              </div>
              <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" placeholder="Enter ..."/>
              </div>
              <div class="form-group">
                <label>Mobie</label>
                <input type="text" name="mobile" class="form-control" placeholder="Enter ..."/>
              </div>
              <div class="form-group">
                <label>Role</label>
                <select class="form-control" name="role">
                  <option value="Lead">Lead</option>
                  <option value="Management">Management</option>
                </select>
              </div>
              
              <div class="form-group">
                <label>Age</label>
                <input type="text" name="age" class="form-control" placeholder="Enter ..."/>
              </div>
              
              <div class="form-group">
                <label>Sex</label>
                <select class="form-control" name="sex">
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>
              
              
              <div class="box-footer">
                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box-body --> 
        </div>
        <!-- /.box --> 
      </div>

<?php
include('footer-include.php');
?>