<?php
include('db_connection.php');
?>

<?php
$msg='';
$sel=mysql_query("INSERT INTO mail(emailto,sub,msg)

VALUES('".$_POST['emailto']."','".$_POST['subject']."','".$_POST['message']."')");
?>