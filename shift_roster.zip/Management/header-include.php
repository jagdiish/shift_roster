<?php
session_start();
if(!isset($_SESSION['identify'])){
header('Location:login.php');	
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>AdminLTE | Dashboard</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<!-- Ionicons -->
<link href="//code.ionicframework.com/ionicons/1.5.2/css/ionicons.min.css" rel="stylesheet" type="text/css" />
<!-- Morris chart -->
<link href="css/morris/morris.css" rel="stylesheet" type="text/css" />
<!-- jvectormap -->
<link href="css/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
<!-- Date Picker -->
<link href="css/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
<!-- Daterange picker -->
<link href="css/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
<!-- bootstrap wysihtml5 - text editor -->
<link href="css/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
<!-- Theme style -->
<link href="css/AdminLTE.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/stylesheet.css" />
<script src="js/validation/jquery-1.4.4.min.js"></script>
<script src="js/validation/happy.js"></script>
<script src="js/validation/happy.methods.js"></script>
<script src="js/validation/val.js"></script>
</head>
<body class="skin-blue">
<!-- header logo: style can be found in header.less -->
<header  class="header"> <a href="index.php" class="logo"> 
  <!-- Add the class icon to your logo image or logo icon to add the margining --> 
  	PETS </a> 
  <!-- Header Navbar: style can be found in header.less -->
  <nav class="navbar navbar-static-top" role="navigation"> 
    <!-- Sidebar toggle button--> 
    <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </a>
    <div class="navbar-right">
      <ul class="nav navbar-nav">
        <li class="dropdown user user-menu"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="glyphicon glyphicon-user"></i> <span>
          <?php $sel=mysql_query(" SELECT * FROM login WHERE id=".$_SESSION['identify']);		  
	  $row=mysql_fetch_array($sel);
	echo $row['username'];
?>
          <i class="caret"></i></span> </a>
          <ul class="dropdown-menu">
            <!-- User image -->
            <li class="user-header bg-light-blue"> <img src="img/avatar04.png" class="img-circle" alt="User Image" />
              <p>
                <?php $sel=mysql_query(" SELECT * FROM login WHERE id=".$_SESSION['identify']);		  
	  $row=mysql_fetch_array($sel);
	  echo $row['username'];	  
?>
                - Web Developer<small>Member since Nov. 2012</small> </p>
            </li>
            <li class="user-footer">
              <div class="pull-left"> <a href="profile.php" class="btn btn-default btn-flat">Profile</a> </div>
              <div class="pull-right"> <a href="logout.php" class="btn btn-default btn-flat">Sign out</a> </div>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </nav>
</header>
<div class="wrapper row-offcanvas row-offcanvas-left">
<!-- Left side column. contains the logo and sidebar -->
<aside class="left-side sidebar-offcanvas"> 
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar"> 
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image"> <img src="img/avatar04.png" class="img-circle" alt="User Image" /> </div>
      <div class="pull-left info">
        <p>Hello,
          <?php $sel=mysql_query(" SELECT * FROM login WHERE id=".$_SESSION['identify']);	
      $row=mysql_fetch_array($sel);
      echo $row['username'];		  
?>
        </p>
         </div>
    </div>
    <?php /*?>FOR SUPER ADMIN<?php */?>
    <?php if(isset($_SESSION['userlevel']) && $_SESSION['userlevel'] == 1){ ?>
    <ul class="sidebar-menu">
      <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='index.php'? 'class="active"' : '');?> class=""> <a href="index.php"> <i class="fa fa-dashboard"></i> <span>Dashboard</span> </a> </li>
      <li> <a href="mailbox.php"> <i class="fa fa-envelope"></i> <span>Mailbox</span> <small class="badge pull-right bg-yellow"></small> </a> </li>
      <li class="treeview"> <a href="#"> <i class="fa fa-folder"></i> <span>Users</span> <i class="fa fa-angle-left pull-right"></i> </a>
        <ul class="treeview-menu">
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='add_user.php'? 'class="active"' : '');?>><a href="add_user.php"><i class="fa fa-angle-double-right"></i> Add New User</a></li>
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='show_users.php'? 'class="active"' : '');?>><a href="show_users.php"><i class="fa fa-angle-double-right second"></i> View User Details</a></li>
          <!--<li><a href="edit_user.php"><i class="fa fa-angle-double-right"></i> </a></li>--> 
          <!--<li><a href="pages/examples/lockscreen.html"><i class="fa fa-angle-double-right"></i> Feedback</a></li>
          <li><a href="pages/examples/404.html"><i class="fa fa-angle-double-right"></i> View feedback</a></li>
          <li><a href="pages/examples/500.html"><i class="fa fa-angle-double-right"></i> add</a></li>
          <li><a href="pages/examples/blank.html"><i class="fa fa-angle-double-right"></i> add</a></li>-->
        </ul>
      </li>
      <li class="treeview"> <a href="#"> <i class="fa fa-folder"></i> <span>Feedabck</span> <i class="fa fa-angle-left pull-right"></i> </a>
        <ul class="treeview-menu">
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='feedback_users.php'? 'class="active"' : '');?>><a href="feedback_users.php"><i class="fa fa-angle-double-right"></i>View Feedback</a></li>
          
          <!--<li><a href="pages/examples/lockscreen.html"><i class="fa fa-angle-double-right"></i> Feedback</a></li>
          <li><a href="pages/examples/404.html"><i class="fa fa-angle-double-right"></i> View feedback</a></li>
          <li><a href="pages/examples/500.html"><i class="fa fa-angle-double-right"></i> add</a></li>
          <li><a href="pages/examples/blank.html"><i class="fa fa-angle-double-right"></i> add</a></li>-->
        </ul>
      </li>
    </ul>
    <?php }?>
    <?php if(isset($_SESSION['userlevel']) && $_SESSION['userlevel'] == 2){ ?>
    <?php /*?>FOR ADMIN<?php */?>
    <ul class="sidebar-menu">
      <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='index.php'? 'class="active"' : '');?> class=""> <a href="index.php"> <i class="fa fa-dashboard"></i> <span>Dashboard</span> </a> </li>
      <li> <a href="mailbox.php"> <i class="fa fa-envelope"></i> <span>Mailbox</span> <small class="badge pull-right bg-yellow"></small> </a> </li>
      <li class="treeview"> <a href="#"> <i class="fa fa-folder"></i> <span>Users</span> <i class="fa fa-angle-left pull-right"></i> </a>
        <ul class="treeview-menu">
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='show_users.php'? 'class="active"' : '');?>><a href="show_users.php"><i class="fa fa-angle-double-right"></i> View User Details</a></li>
          <!--<li><a href="edit_user.php"><i class="fa fa-angle-double-right"></i> </a></li>--> 
          <!--<li><a href="pages/examples/lockscreen.html"><i class="fa fa-angle-double-right"></i> Feedback</a></li>
          <li><a href="pages/examples/404.html"><i class="fa fa-angle-double-right"></i> View feedback</a></li>
          <li><a href="pages/examples/500.html"><i class="fa fa-angle-double-right"></i> add</a></li>
          <li><a href="pages/examples/blank.html"><i class="fa fa-angle-double-right"></i> add</a></li>-->
        </ul>
      </li>
      <li class="treeview"> <a href="#"> <i class="fa fa-folder"></i> <span>Feedabck</span> <i class="fa fa-angle-left pull-right"></i> </a>
        <ul class="treeview-menu">
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='feedback_users.php'? 'class="active"' : '');?>><a href="feedback_users.php"><i class="fa fa-angle-double-right"></i>View Feedback</a></li>
          
          <!--<li><a href="pages/examples/lockscreen.html"><i class="fa fa-angle-double-right"></i> Feedback</a></li>
          <li><a href="pages/examples/404.html"><i class="fa fa-angle-double-right"></i> View feedback</a></li>
          <li><a href="pages/examples/500.html"><i class="fa fa-angle-double-right"></i> add</a></li>
          <li><a href="pages/examples/blank.html"><i class="fa fa-angle-double-right"></i> add</a></li>-->
        </ul>
      </li>
    </ul>
    <?php }?>
    <?php if(isset($_SESSION['userlevel']) && $_SESSION['userlevel'] == 3){ ?>
    <?php /*?>FOR USER<?php */?>
    <ul class="sidebar-menu">
      <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='index.php'? 'class="active"' : '');?> class=""> <a href="index.php"> <i class="fa fa-dashboard"></i> <span>Dashboard</span> </a> </li>
      <li> <a href="mailbox.php"> <i class="fa fa-envelope"></i> <span>Mailbox</span> <small class="badge pull-right bg-yellow"></small> </a> </li>
      <li class="treeview"> <a href="#"> <i class="fa fa-folder"></i> <span>Feedabck</span> <i class="fa fa-angle-left pull-right"></i> </a>
        <ul class="treeview-menu">
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='feedback_users.php'? 'class="active"' : '');?>><a href="display_fb.php"><i class="fa fa-angle-double-right"></i>View Feedback</a></li>
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='feedback.php'? 'class="active"' : '');?>><a href="feedback.php"><i class="fa fa-angle-double-right"></i> Add Feedback</a></li>
          <li <?php echo (basename($_SERVER['SCRIPT_FILENAME'])=='fb_draft.php'? 'class="active"' : '');?>><a href="fb_draft.php"><i class="fa fa-angle-double-right"></i> Feedback in Draft</a></li>
          <!--<li><a href="pages/examples/lockscreen.html"><i class="fa fa-angle-double-right"></i> Feedback</a></li>
          <li><a href="pages/examples/404.html"><i class="fa fa-angle-double-right"></i> View feedback</a></li>
          <li><a href="pages/examples/500.html"><i class="fa fa-angle-double-right"></i> add</a></li>
          <li><a href="pages/examples/blank.html"><i class="fa fa-angle-double-right"></i> add</a></li>-->
        </ul>
      </li>
    </ul>
    <?php }?>
  </section>
  <!-- /.sidebar --> 
</aside>

<!-- Right side column. Contains the navbar and content of the page -->
<aside class="right-side">
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1> Dashboard <small>Control panel</small> </h1>
  <ol class="breadcrumb">
    <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active"></li>
  </ol>
</section>
<section class="content">
