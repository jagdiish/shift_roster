// Login
<?php 
include 'db_connect.php'; ob_start();
if(isset($_POST['uName']) && !empty($_POST['uName'])){
$qRy="SELECT id, userlevel FROM admin WHERE status='Active' AND ( username='".$_POST['uName']."' AND password='".$_POST['uPwd']."')";
$chkQry=mysql_query($qRy);	
if(mysql_num_rows($chkQry)>0){  
$login_row = mysql_fetch_assoc($chkQry); 
$_SESSION['adminId']=$login_row['id'];	
$_SESSION['userlevel']=$login_row['userlevel'];	
echo 'dashboard.php';
}
else{   echo '$$$$@@@@$$$$'; }
exit;
}
?>


//header
<?php if(isset($_SESSION['userlevel']) && $_SESSION['userlevel'] == 0){ ?>
<li><a href="add_client.php"><i class="icon-user"></i> Add New Client</a></li>
<li><a href="clients_list.php"><i class="icon-table"></i> View/Edit Clients</a></li>
<li><a href="client_renewal.php"><i class="icon-time"></i> Client Renewals</a></li>
<li><a href="client_email.php"><i class="icon-envelope-alt"></i> Send Email</a></li>
                                <?php 
}else if($_SESSION['userlevel'] == 1){ ?>
<li><a href="clients_list.php"><i class="icon-table"></i> View Clients</a></li>
                                    <li><a href="client_renewal.php"><i class="icon-time"></i> Client Renewals</a></li>
<?php }?>