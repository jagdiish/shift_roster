<?php
include('db_connection.php');
?>
<?php /*?><?php header('Location:show_users.php?result=ok'); ?><?php */?>

<?php

if(isset($_POST['submit']))
{
$ins=mysql_query("INSERT INTO login (username,pwd,email,mobile,role,age,sex)VALUES
('".$_POST['username']."',
'".$_POST['pwd']."',
'".$_POST['email']."',
'".$_POST['mobile']."',
'".$_POST['role']."',
'".$_POST['age']."',
'".$_POST['sex']."')");
}

?>