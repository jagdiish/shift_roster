<?php
include('db_connection.php');
?>

<?php
$msg='';
$sel=mysql_query("INSERT INTO mail(emailto,sub,msg)

VALUES('".$_POST['emailto']."','".$_POST['subject']."','".$_POST['message']."')");
?>
<?php
$to = $_POST['emailto'];
$from = "jagadheesh@dsignzmedia.in";

//$Cc = "";

//$Bcc = "";
$subject = $_POST['subject'];
$message = $_POST['message'];

$headers = "From: $from\n";
//$headers .="Cc: $Cc\n";
//$headers .= "Bcc: $Bcc\n";
$headers .= "MIME-Version:1.0\n";
$headers .= "Content-type: text/html \n";


mail($to, $subject, $message, $headers);


?>