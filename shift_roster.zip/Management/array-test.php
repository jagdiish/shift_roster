<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<?php
mysql_connect('localhost','root','');
mysql_select_db('array');
?>


<form method="post" name="myform">
Name1:<input name="achieve[]" type="text"  value="" size=""/><br/>
Name2:<input name="achieve[]" type="text"  value="" size="%"/><br/>

<input name="submit" type="submit"  value="SUBMIT" size="66%"/>
</form>

<?php


if(isset($_POST['submit'])){
$ach=implode(',',$_POST['achieve']);
$ins=mysql_query("INSERT INTO array_store(achieve) VALUES('".$ach."')");
}

?>
</body>
</html>