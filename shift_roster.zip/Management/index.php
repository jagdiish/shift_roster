<?php
include('db_connection.php');
?>
<?php
include('header-include.php');
?>
      <?php
if(!isset($_SESSION['identify'])){
header('Location:login.php');	
}
?>
      <?php /*?>FOR SUPER ADMIN<?php */?>
      <?php if(isset($_SESSION['userlevel']) && $_SESSION['userlevel'] == 1){ ?>
      <div class="row">
        <div class="col-lg-3 col-xs-6"> 
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3> </h3>
              <p> No.of Employees </p>
            </div>
            <div class="icon"> <i class="ion ion-person-add"></i> </div>
            <a href="show_users.php" class="small-box-footer"> View Details <i class="fa fa-arrow-circle-right"></i> </a> </div>
        </div>
        
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6"> 
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3> <sup style="font-size: 20px"></sup> </h3>
              <p> Feedback Submitted </p>
            </div>
            <div class="icon"> <i class="ion ion-stats-bars"></i> </div>
            <a href="feedback_users.php" class="small-box-footer"> More info <i class="fa fa-arrow-circle-right"></i> </a> </div>
        </div>
        <!-- ./col --> 
        
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6"> 
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3></h3>
              <p> General </p>
            </div>
            <div class="icon"> <i class="ion ion-pie-graph"></i> </div>
            <a href="#" class="small-box-footer"> More info <i class="fa fa-arrow-circle-right"></i> </a> </div>
        </div>
        <!-- ./col --> 
      </div>
      <?php }?>
      <?php /*?>FOR ADMIN<?php */?>
      <?php if(isset($_SESSION['userlevel']) && $_SESSION['userlevel'] == 2){ ?>
      <div class="row">
        <div class="col-lg-3 col-xs-6"> 
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3> </h3>
              <p> No.of Employees </p>
            </div>
            <div class="icon"> <i class="ion ion-person-add"></i> </div>
            <a href="show_users.php" class="small-box-footer"> View Details <i class="fa fa-arrow-circle-right"></i> </a> </div>
        </div>
        
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6"> 
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3> <sup style="font-size: 20px"></sup> </h3>
              <p> Feedback Submitted </p>
            </div>
            <div class="icon"> <i class="ion ion-stats-bars"></i> </div>
            <a href="feedback_users.php" class="small-box-footer"> More info <i class="fa fa-arrow-circle-right"></i> </a> </div>
        </div>
        <!-- ./col --> 
        
        <!-- ./col --> 
        
        <!-- ./col --> 
      </div>
      <?php }?>
      <?php /*?>FOR USER<?php */?>
      <?php if(isset($_SESSION['userlevel']) && $_SESSION['userlevel'] == 3){ ?>
      <div class="row"> 
        
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6"> 
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3> <sup style="font-size: 20px"></sup> </h3>
              <p> Feedback Submitted </p>
            </div>
            <div class="icon"> <i class="ion ion-stats-bars"></i> </div>
            <a href="feedback_users.php" class="small-box-footer"> More info <i class="fa fa-arrow-circle-right"></i> </a> </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6"> 
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3></h3>
              <p>Feedback in Draft </p>
            </div>
            <div class="icon"> <i class="ion ion-person-add"></i> </div>
            <a href="fb_draft.php" class="small-box-footer"> More info <i class="fa fa-arrow-circle-right"></i> </a> </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6"> 
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3></h3>
              <p> General </p>
            </div>
            <div class="icon"> <i class="ion ion-pie-graph"></i> </div>
            <a href="#" class="small-box-footer"> More info <i class="fa fa-arrow-circle-right"></i> </a> </div>
        </div>
        <!-- ./col --> 
      </div>
      <?php }?>
      
      <!-- PREV FILE IMP!! -->
      
      <?php
include('db_connection.php');

if(isset($_SESSION['userlevel']) && $_SESSION['userlevel'] == 2 ){
	
	$sel=mysql_query("SELECT * FROM login WHERE role='User' AND allocate=".$_SESSION['identify']) ;
		
}
else  if(isset($_SESSION['userlevel']) && $_SESSION['userlevel'] == 1 )
{ 
$sel=mysql_query("SELECT * FROM login WHERE role='User' ORDER BY allocate ASC ") ; 


} 


?>
      <?php
if(isset($_SESSION['userlevel']) && $_SESSION['userlevel'] == 3 ){
//echo 'no';
$uid = $_SESSION['identify'];
$sel1 = mysql_query("SELECT * FROM feedback_table WHERE usr_id=".$uid);
$count1 = mysql_num_rows($sel1);
if($count1 == 1){ ?>
      <div class="row"> 
        <!-- left column -->
        <div class="col-md-12">
          <h2>Your Status</h2>
          <div class="box-body" style="background:#3c8dbc; ">
            <div class="form-group" style="margin-top:20px;">
              <label style="padding:10px 10px; color:#fff;" for="exampleInputEmail1">You have submitted the feedback.</label>
            </div>
          </div>
        </div>
      </div>
      <?php }
 else if($count1 == 0){ ?>
      <div class="row"> 
        <!-- left column -->
        <div class="col-md-12">
          <h2>Your Status</h2>
          <div class="box-body" style="background:#3c8dbc; ">
            <div class="form-group" style="margin-top:20px;">
              <label style="padding:10px 10px; color:#fff;" for="exampleInputEmail1">You have not submitted the feedback.</label>
            </div>
          </div>
        </div>
      </div>
      <?php 
 }

}

else { ?>
      <table class="table table-striped display" border="4">
        <tr>
          <th>Lead</th>
          <th class="emp">USER NAME</th>
          <th class="name">EMAIL</th>
        </tr>
        <?php		
}
?>
        <?php while($row = mysql_fetch_array($sel)){
			$sel_lead=mysql_query("SELECT username FROM login WHERE id=".$row['allocate']);
			
		while($row1=mysql_fetch_array($sel_lead))
		{ 		
				
		?>
        
          <td><?php echo $row1['username']; ?></td>
          <?php } ?>
          <td><?php echo $row['username']; ?></td>
          <td><?php echo $row['email']; ?></td>
        </tr>
        <?php } ?>
      </table>
      <div class="row"> 
        <!-- Left col -->
        <section class="col-lg-7 "> 
          
          <!-- Custom tabs (Charts with tabs)--> 
          <!-- /.nav-tabs-custom --> 
          
          <!-- Chat box --> 
          <!-- /.box (chat box) --> 
          
          <!-- TO DO List --> 
          <!-- /.box --> 
          
          <!-- quick email widget --> 
          
        </section>
        <!-- /.Left col --> 
        <!-- right col (We are only adding the ID to make the widgets sortable)--> 
        <!-- right col --> 
      </div>
      <!-- /.row (main row) --> 
      
    </section>
    <!-- /.content --> 
  </aside>
  <!-- /.right-side --> 
</div>

<!----  ul 1  ---->

<?php
include('footer-include.php');
?>
