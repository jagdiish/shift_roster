<?php
ob_start();
?>
<?php
include('db_connection.php');
?>
<?php
include('header-include.php');
?>
<link rel="stylesheet" type="text/css" href="css/elements.css">
<div id="feedback"> 
  <!-- heading of the form -->
  <form id="form" action="#" method="post">
    <div class="form-group">
      <div class="input-group"> <span class="input-group-addon">NAME:</span>
        <input name="vname" type="text" class="form-control" placeholder="Your Name">
      </div>
    </div>
    <div class="form-group">
      <div class="input-group"> <span class="input-group-addon">EMAIL:</span>
        <input name="vemail" type="email" class="form-control" placeholder="Your Email">
      </div>
    </div>
    <div class="form-group">
      <div class="input-group"> <span class="input-group-addon">SUBJECT:</span>
        <input name="sub" type="text" class="form-control" placeholder="Your Subject">
      </div>
    </div>
    <textarea name="msg" id="email_message" class="form-control" placeholder="Message" style="height: 120px;"></textarea>
    <div class="modal-footer clearfix">
      <button type="submit" id="" name="submit" class="btn btn-primary pull-left"><i class="fa fa-envelope"></i> Send Message</button>
    </div>
  </form>
  
  <!-- feedback form form --> 
  <!--<form id="form" action="#" method="post">
    <input type = "text" name="vname" value="" placeholder="Your Name"/>
    <input type = "text" name="vemail" value="" placeholder="Your Email"/>
    <input type = "text" name="sub" value="" placeholder="Subject"/>
    <textarea name="msg" placeholder="Type your text here..."></textarea>
    <input type="submit" name="submit" id="send" value="Send Mail"/>
  </form>-->
  <h3>
    <?php include "secure_email_code.php"?>
  </h3>
</div>
<?php
include('footer-include.php');
?>
<?php
ob_end_flush();
?>