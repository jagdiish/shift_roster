<?php
session_start();

?>
<?php
include('db_connection.php');
?>

<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="ie6 ielt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="ie7 ielt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="ie8"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--> <html lang="en"> <!--<![endif]-->
<head>
<meta charset="utf-8">
<title>Login Page</title>
<link rel="stylesheet" type="text/css" href="css/login-style.css" />
</head>
<body>
<div class="container">
	<section id="content">
		<form action="" method="post" id="form" name="form1">
			<h1>Login Form</h1>
			<div>
				<input type="text" name="uname" placeholder="Username" required="" id="username" />
			</div>
			<div>
				<input type="password" name="pword" placeholder="Password" required="" id="password" />
			</div>
			<div>
				<input type="submit" name="submit" id="sub" value="Log in" />
				
			</div>
		</form><!-- form -->
		<!-- button -->
	</section><!-- content -->
</div><!-- container -->

<?php
if(isset($_POST['submit'])){

$sel=mysql_query("SELECT * FROM login WHERE username='".$_POST['uname']."' AND pwd='".$_POST['pword']."' ");	
$num=mysql_num_rows($sel);

if($num==1){
$row=mysql_fetch_array($sel);
$_SESSION['identify']=$row['id'];	
$_SESSION['userlevel']=$row['userlevel'];
		
header('Location:index.php');		
}
else { 
header('Location:login.php');
echo "Login Failed !!!";
	}	
}

?>



</body>
</html>